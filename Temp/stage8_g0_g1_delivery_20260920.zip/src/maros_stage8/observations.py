"""Capability-separated observations built outside every Stage-8 Agent."""
from __future__ import annotations

from dataclasses import dataclass

import torch
from torch.nn import functional as F


def _validate_iq(iq: torch.Tensor) -> None:
    if not torch.is_tensor(iq):
        raise TypeError("I/Q must be a torch.Tensor")
    if iq.ndim != 3 or iq.shape[1] != 2 or iq.shape[-1] < 16:
        raise ValueError("I/Q must have shape [batch, 2, length>=16]")
    if not iq.is_floating_point():
        raise TypeError("I/Q must be floating point")
    if not torch.isfinite(iq).all():
        raise ValueError("I/Q contains non-finite values")


@dataclass(frozen=True)
class TemporalObservation:
    """The only observation accepted by TemporalFingerprintAgent."""

    iq: torch.Tensor

    def __post_init__(self) -> None:
        _validate_iq(self.iq)


@dataclass(frozen=True)
class SpectralObservation:
    """Frequency-domain features with no recoverable raw-I/Q field."""

    features: torch.Tensor
    quality: torch.Tensor

    def __post_init__(self) -> None:
        if (not torch.is_tensor(self.features) or self.features.ndim != 3
                or self.features.shape[1] != 6):
            raise ValueError("spectral features must have shape [batch, 6, bins]")
        if self.features.shape[-1] < 16 or not self.features.is_floating_point():
            raise ValueError("spectral features require at least 16 floating bins")
        if (not torch.is_tensor(self.quality) or self.quality.ndim != 2
                or self.quality.shape != (self.features.shape[0], 6)):
            raise ValueError("spectral quality must have shape [batch, 6]")
        if not torch.isfinite(self.features).all() or not torch.isfinite(self.quality).all():
            raise ValueError("spectral observation contains non-finite values")


@dataclass(frozen=True)
class RegistrationObservation:
    """Future Memory-Agent input; never aliases an A/B private embedding."""

    descriptor: torch.Tensor

    def __post_init__(self) -> None:
        if not torch.is_tensor(self.descriptor) or self.descriptor.ndim != 2:
            raise ValueError("registration descriptor must have shape [batch, dim]")


@dataclass(frozen=True)
class AuditObservation:
    """Future consistency-audit input owned by the perturbation service."""

    iq: torch.Tensor
    perturbation_budget: torch.Tensor

    def __post_init__(self) -> None:
        _validate_iq(self.iq)
        if (not torch.is_tensor(self.perturbation_budget)
                or self.perturbation_budget.shape != (self.iq.shape[0],)):
            raise ValueError("perturbation_budget must have shape [batch]")


def build_temporal_observation(iq: torch.Tensor) -> TemporalObservation:
    """Register raw I/Q for the temporal capability without transforming it."""

    return TemporalObservation(iq=iq)


def build_spectral_observation(iq: torch.Tensor) -> SpectralObservation:
    """Convert raw I/Q into the Spectral Agent's complete private view.

    FFT is deliberately confined to this external builder.  The returned type
    exposes only frequency-domain channels; SpectralFingerprintAgent has no
    method accepting raw I/Q or TemporalObservation.
    """

    _validate_iq(iq)
    z = torch.complex(iq[:, 0], iq[:, 1])
    spectrum = torch.fft.fftshift(
        torch.fft.fft(z, dim=-1, norm="ortho"), dim=-1)
    magnitude = spectrum.abs().clamp_min(1e-7)
    power = magnitude.square()
    log_power = torch.log1p(power)
    log_power = (log_power - log_power.mean(1, keepdim=True)) / (
        log_power.std(1, keepdim=True).clamp_min(1e-5))
    delta = F.pad(log_power[:, 1:] - log_power[:, :-1], (1, 0))
    asymmetry = log_power - torch.flip(log_power, dims=(-1,))
    centered_power = power / power.mean(1, keepdim=True).clamp_min(1e-7)
    envelope = F.avg_pool1d(
        log_power[:, None], kernel_size=9, stride=1, padding=4).squeeze(1)
    phase = torch.angle(spectrum)
    phase_step = torch.atan2(
        torch.sin(phase[:, 1:] - phase[:, :-1]),
        torch.cos(phase[:, 1:] - phase[:, :-1]))
    phase_magnitude = F.pad(phase_step.abs(), (1, 0))
    phase_roughness = F.pad(
        (phase_step[:, 1:] - phase_step[:, :-1]).abs(), (2, 0))
    features = torch.stack([
        log_power,
        envelope,
        delta,
        asymmetry,
        phase_magnitude,
        phase_roughness,
    ], dim=1).to(dtype=iq.dtype)

    probability = power / power.sum(1, keepdim=True).clamp_min(1e-7)
    entropy = -(probability * probability.clamp_min(1e-9).log()).sum(1)
    entropy = entropy / torch.log(torch.tensor(
        power.shape[1], device=power.device, dtype=power.dtype))
    quality = torch.stack([
        log_power.abs().mean(1),
        log_power.std(1),
        centered_power.amax(1).log1p(),
        asymmetry.abs().mean(1),
        phase_step.abs().mean(1),
        entropy,
    ], dim=1).to(dtype=iq.dtype)
    return SpectralObservation(features=features, quality=quality)
