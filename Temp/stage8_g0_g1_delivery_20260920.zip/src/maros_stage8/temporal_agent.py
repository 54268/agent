"""Raw-I/Q-only temporal fingerprint and candidate verifier."""
from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn
from torch.nn import functional as F

from .contracts import (EvidenceCertificate, EvidenceStance, LocalDecision,
                        QueryPacket, QueryType)
from .observations import TemporalObservation


@dataclass(frozen=True)
class _TemporalPrivateState:
    state: torch.Tensor
    quality: torch.Tensor


class TemporalFingerprintAgent(nn.Module):
    """Temporal transient specialist; it has no spectral or memory API."""

    name = "temporal"

    def __init__(self, num_classes: int, state_dim: int = 96,
                 hidden_channels: int = 64, scalar_bits: int = 16):
        super().__init__()
        if num_classes < 2:
            raise ValueError("at least two Known classes are required")
        self.encoder = nn.Sequential(
            nn.Conv1d(2, hidden_channels, 9, stride=2, padding=4),
            nn.BatchNorm1d(hidden_channels), nn.GELU(),
            nn.Conv1d(hidden_channels, hidden_channels * 2, 7,
                      stride=2, padding=3),
            nn.BatchNorm1d(hidden_channels * 2), nn.GELU(),
            nn.Conv1d(hidden_channels * 2, state_dim, 5,
                      stride=2, padding=2),
            nn.GELU(), nn.AdaptiveAvgPool1d(1),
        )
        self.classifier = nn.Linear(state_dim, num_classes)
        self.class_embedding = nn.Embedding(num_classes, state_dim)
        self.verifier = nn.Sequential(
            nn.LayerNorm(4 * state_dim), nn.Linear(4 * state_dim, state_dim),
            nn.GELU(), nn.Linear(state_dim, 1),
        )
        self.num_classes = int(num_classes)
        self.scalar_bits = int(scalar_bits)

    @staticmethod
    def _quality(iq: torch.Tensor) -> torch.Tensor:
        amplitude = torch.linalg.vector_norm(iq, dim=1)
        delta = iq[:, :, 1:] - iq[:, :, :-1]
        return torch.stack([
            amplitude.mean(1), amplitude.std(1),
            delta.square().mean((1, 2)).sqrt(),
        ], dim=1)

    def _encode(self, observation: TemporalObservation) -> _TemporalPrivateState:
        if not isinstance(observation, TemporalObservation):
            raise TypeError("TemporalFingerprintAgent requires TemporalObservation")
        state = self.encoder(observation.iq).squeeze(-1)
        return _TemporalPrivateState(state=state, quality=self._quality(observation.iq))

    def _decision(self, private: _TemporalPrivateState) -> LocalDecision:
        logits = self.classifier(private.state)
        probability = logits.softmax(1)
        top = probability.topk(2, dim=1)
        entropy = -(probability * probability.clamp_min(1e-9).log()).sum(1)
        margin = top.values[:, 0] - top.values[:, 1]
        unknown = entropy - logits.amax(1)
        public = torch.cat([
            top.values, margin[:, None], entropy[:, None],
            unknown[:, None], private.quality,
        ], dim=1)
        return LocalDecision(
            sender=self.name, class_logits=logits, unknown_score=unknown,
            top1=top.indices[:, 0], top2=top.indices[:, 1],
            public_diagnostics=public)

    def forward_private(
        self, observation: TemporalObservation,
    ) -> tuple[LocalDecision, _TemporalPrivateState]:
        private = self._encode(observation)
        return self._decision(private), private

    def forward(self, observation: TemporalObservation) -> LocalDecision:
        return self.forward_private(observation)[0]

    def verification_scores(
        self, private: _TemporalPrivateState, candidates: torch.Tensor,
    ) -> torch.Tensor:
        if not isinstance(private, _TemporalPrivateState):
            raise TypeError("Temporal verifier requires its own private state")
        candidates = candidates.long().to(private.state.device)
        if candidates.shape != (len(private.state),):
            raise ValueError("candidates must have shape [batch]")
        if bool(((candidates < 0) | (candidates >= self.num_classes)).any()):
            raise ValueError("candidate is outside the Known class range")
        descriptor = self.class_embedding(candidates)
        values = torch.cat([
            private.state, descriptor,
            (private.state - descriptor).abs(), private.state * descriptor,
        ], dim=1)
        return self.verifier(values).squeeze(1)

    def verify(self, private: _TemporalPrivateState,
               query: QueryPacket) -> EvidenceCertificate:
        if query.receiver != self.name or query.query_type != QueryType.VERIFY_TEMPORAL_PAIR:
            raise ValueError("Temporal Agent only answers temporal-pair queries")
        score_a = self.verification_scores(private, query.candidate_a)
        score_b = self.verification_scores(private, query.candidate_b)
        signed = score_a - score_b
        reliability = torch.sigmoid(signed.abs())
        stance = torch.where(
            signed >= 0, torch.full_like(query.candidate_a, int(EvidenceStance.SUPPORT_A)),
            torch.full_like(query.candidate_a, int(EvidenceStance.SUPPORT_B)))
        alternative = torch.where(signed >= 0, query.candidate_a, query.candidate_b)
        active = query.active_mask.bool()
        abstain = (~active) | reliability.lt(0.55)
        stance = torch.where(abstain, torch.full_like(stance, int(EvidenceStance.ABSTAIN)), stance)
        bits = active.to(signed) * float(2 + 3 * self.scalar_bits)
        zeros = torch.zeros_like(signed)
        return EvidenceCertificate(
            sender=self.name, receiver=query.sender,
            candidate_a=query.candidate_a, candidate_b=query.candidate_b,
            stance=torch.where(active, stance, torch.zeros_like(stance)),
            signed_candidate_evidence=torch.where(active, signed, zeros),
            alternative_class=torch.where(active, alternative, torch.zeros_like(alternative)),
            domain_quality=torch.where(active, private.quality.mean(1), zeros),
            open_risk=zeros, reliability=torch.where(active, reliability, zeros),
            abstain=abstain, active_mask=active, bit_cost=bits)

