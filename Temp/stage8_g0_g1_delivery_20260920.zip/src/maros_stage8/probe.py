"""Small, leakage-safe G0/G1 probe for Temporal/Spectral specialization."""
from __future__ import annotations

import json
import random
from pathlib import Path
from typing import Mapping

import numpy as np
import torch
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, Dataset, Subset

from maros_staged.datasets import load_oracle_npz, load_wisig_subset

from .audit import capability_audit
from .evaluation import (open_set_rescue_metrics, rescue_labels)
from .gates import evaluate_g15_gate, evaluate_g1_gate
from .observations import (build_spectral_observation,
                           build_temporal_observation)
from .splits import (assert_no_formal_unknown, build_nested_lco_protocol,
                     protocol_manifest)
from .system import Stage8System
from .training import local_specialization_objective


def _seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def _cap(dataset: Dataset, per_class: int, seed: int) -> Dataset:
    if per_class <= 0:
        return dataset
    labels = np.asarray(
        getattr(dataset, "original_labels", dataset.y), dtype=np.int64)
    rng = np.random.default_rng(seed)
    chosen = []
    for label in np.unique(labels):
        indices = np.flatnonzero(labels == label)
        rng.shuffle(indices)
        chosen.extend(indices[:per_class].tolist())
    return Subset(dataset, sorted(chosen))


def _train(system: Stage8System, dataset: Dataset, cfg: Mapping,
           device: torch.device, seed: int) -> list[dict[str, float]]:
    assert_no_formal_unknown(dataset)
    loader = DataLoader(
        _cap(dataset, int(cfg["train_samples_per_class"]), seed),
        batch_size=int(cfg["batch_size"]), shuffle=True,
        generator=torch.Generator().manual_seed(seed))
    optimizer = torch.optim.AdamW(
        system.parameters(), lr=float(cfg["learning_rate"]),
        weight_decay=float(cfg["weight_decay"]))
    history = []
    for epoch in range(int(cfg["epochs"])):
        system.train()
        total_loss = temporal_correct = spectral_correct = seen = 0
        for iq, labels in loader:
            iq, labels = iq.to(device), labels.to(device)
            optimizer.zero_grad(set_to_none=True)
            loss, pieces = local_specialization_objective(
                system, build_temporal_observation(iq),
                build_spectral_observation(iq), labels,
                verification_weight=float(cfg["verification_weight"]),
                pair_margin=float(cfg["pair_margin"]))
            loss.backward()
            optimizer.step()
            batch = len(labels)
            total_loss += float(loss.detach()) * batch
            temporal_correct += int(
                pieces["decisions"]["temporal"].top1.eq(labels).sum())
            spectral_correct += int(
                pieces["decisions"]["spectral"].top1.eq(labels).sum())
            seen += batch
        history.append({
            "epoch": float(epoch + 1), "loss": total_loss / max(seen, 1),
            "temporal_train_accuracy": temporal_correct / max(seen, 1),
            "spectral_train_accuracy": spectral_correct / max(seen, 1),
        })
    return history


@torch.no_grad()
def _collect(system: Stage8System, dataset: Dataset, cfg: Mapping,
             device: torch.device, seed: int) -> dict[str, np.ndarray]:
    assert_no_formal_unknown(dataset)
    loader = DataLoader(
        _cap(dataset, int(cfg["eval_samples_per_class"]), seed),
        batch_size=int(cfg["batch_size"]), shuffle=False)
    result: dict[str, list[np.ndarray]] = {
        key: [] for key in (
            "labels", "temporal_prediction", "spectral_prediction",
            "temporal_unknown", "spectral_unknown", "features")}
    system.eval()
    for iq, labels in loader:
        context = system.observe(iq.to(device))
        temporal = context["temporal"]
        spectral = context["spectral"]
        common = torch.abs(
            temporal.public_diagnostics[:, :5]
            - spectral.public_diagnostics[:, :5])
        features = torch.cat([
            temporal.public_diagnostics, spectral.public_diagnostics, common,
        ], dim=1)
        values = {
            "labels": labels,
            "temporal_prediction": temporal.top1,
            "spectral_prediction": spectral.top1,
            "temporal_unknown": temporal.unknown_score,
            "spectral_unknown": spectral.unknown_score,
            "features": features,
        }
        for key, value in values.items():
            result[key].append(value.detach().cpu().numpy())
    return {key: np.concatenate(value) for key, value in result.items()}


def _threshold(calibration: dict[str, np.ndarray], name: str,
               acceptance: float) -> float:
    return float(np.quantile(calibration[f"{name}_unknown"], acceptance))


def _final_predictions(rows: dict[str, np.ndarray], name: str,
                       threshold: float) -> np.ndarray:
    prediction = rows[f"{name}_prediction"].copy()
    prediction[rows[f"{name}_unknown"] >= threshold] = -1
    return prediction


def _macro_auroc(train_x, train_y, test_x, test_y) -> float:
    classes = np.unique(train_y)
    if len(classes) < 2:
        return 0.5
    model = make_pipeline(
        StandardScaler(),
        LogisticRegression(
            max_iter=1000, class_weight="balanced", random_state=0))
    model.fit(train_x, train_y)
    probabilities = model.predict_proba(test_x)
    fitted_classes = model[-1].classes_
    values = []
    for column, label in enumerate(fitted_classes):
        target = test_y == label
        if target.any() and (~target).any():
            values.append(roc_auc_score(target, probabilities[:, column]))
    return float(np.mean(values)) if values else 0.5


def _load(cfg: Mapping):
    if cfg["dataset"] == "wisig":
        return load_wisig_subset(cfg["wisig_pkl"], augment_train=False)
    if cfg["dataset"] == "oracle":
        return load_oracle_npz(cfg["oracle_root"], augment_train=False)
    raise ValueError("dataset must be wisig or oracle")


def run_g1_probe(cfg: Mapping) -> dict:
    """Run four tiny inner LCO episodes without touching formal Unknown."""

    seed = int(cfg["seed"])
    _seed(seed)
    splits = _load(cfg)
    protocol = build_nested_lco_protocol(
        splits, outer_folds=int(cfg["outer_folds"]),
        inner_folds=4, seed=int(cfg["partition_seed"]))
    outer = protocol.outer_folds[int(cfg["outer_fold"])]
    device = torch.device(
        "cuda" if torch.cuda.is_available() and cfg.get("device", "auto") != "cpu"
        else "cpu")
    fold_results = []
    predictor_rows = []
    for episode in outer.inner_folds:
        fold_seed = seed + 1009 * (episode.inner_index + 1)
        _seed(fold_seed)
        system = Stage8System(
            len(episode.known_classes), state_dim=int(cfg["state_dim"]),
            hidden_channels=int(cfg["hidden_channels"])).to(device)
        history = _train(system, episode.train_known, cfg, device, fold_seed)
        calibration = _collect(
            system, episode.calibration_known, cfg, device, fold_seed + 1)
        known = _collect(system, episode.test_known, cfg, device, fold_seed + 2)
        proxy = _collect(
            system, episode.test_proxy_unknown, cfg, device, fold_seed + 3)
        combined = {
            key: np.concatenate([known[key], proxy[key]])
            for key in known}
        temporal_threshold = _threshold(
            calibration, "temporal", float(cfg["known_acceptance"]))
        spectral_threshold = _threshold(
            calibration, "spectral", float(cfg["known_acceptance"]))
        temporal_prediction = _final_predictions(
            combined, "temporal", temporal_threshold)
        spectral_prediction = _final_predictions(
            combined, "spectral", spectral_threshold)
        rescue = open_set_rescue_metrics(
            combined["labels"], temporal_prediction, spectral_prediction)
        predictor_rows.append({
            "features": combined["features"],
            "labels": rescue_labels(
                combined["labels"], temporal_prediction, spectral_prediction),
        })
        fold_results.append({
            "inner_fold": episode.inner_index,
            "known_classes": list(episode.known_classes),
            "proxy_unknown_classes": list(episode.proxy_unknown_classes),
            "training": history,
            "temporal_threshold": temporal_threshold,
            "spectral_threshold": spectral_threshold,
            **rescue.__dict__,
        })

    aurocs = []
    for heldout in range(len(predictor_rows)):
        train_x = np.concatenate([
            row["features"] for index, row in enumerate(predictor_rows)
            if index != heldout])
        train_y = np.concatenate([
            row["labels"] for index, row in enumerate(predictor_rows)
            if index != heldout])
        test_x = predictor_rows[heldout]["features"]
        test_y = predictor_rows[heldout]["labels"]
        aurocs.append(_macro_auroc(train_x, train_y, test_x, test_y))

    # Rehydrate the immutable gate rows without exposing per-sample labels in
    # the persisted report.
    from .evaluation import OpenSetRescueMetrics
    rescue_objects = [OpenSetRescueMetrics(**{
        key: row[key] for key in OpenSetRescueMetrics.__dataclass_fields__
    }) for row in fold_results]
    g1 = evaluate_g1_gate(
        rescue_objects,
        min_unique_rescue=float(cfg["g1_min_unique_rescue"]),
        min_oracle_headroom=float(cfg["g1_min_oracle_headroom"]),
        min_local_known_accuracy=float(cfg["g1_min_local_known_accuracy"]))
    g15 = evaluate_g15_gate(
        aurocs, min_macro_auroc=float(cfg["g15_min_macro_auroc"]),
        min_positive_folds=int(cfg["g15_min_positive_folds"]))
    # G1.5 cannot unlock downstream work if G1 itself failed.
    unlock = bool(g1.passed and g15.passed)
    report = {
        "stage": "stage8_g0_g1_probe",
        "dataset": cfg["dataset"], "device": str(device),
        "formal_unknown_used": False,
        "formal_unknown_sample_count": protocol.formal_unknown_sample_count,
        "capability_audit": capability_audit().as_dict(),
        "folds": fold_results,
        "cross_class_rescue_macro_auroc_by_fold": aurocs,
        "g1_gate": g1.as_dict(), "g15_gate": g15.as_dict(),
        "memory_auditor_unlocked": unlock,
        "forced_consultation_unlocked": unlock,
        "decision": ("proceed_to_memory_auditor_and_forced_consultation"
                     if unlock else "stop_and_redesign_ab"),
        "protocol": protocol_manifest(protocol),
    }
    output = Path(cfg["output_dir"])
    output.mkdir(parents=True, exist_ok=True)
    (output / "g1_probe_report.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    return report
