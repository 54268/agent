"""G1 complementarity and G1.5 rescue-predictability diagnostics."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


def _safe_h(known_accuracy: float, unknown_recall: float) -> float:
    total = known_accuracy + unknown_recall
    return 0.0 if total <= 0 else 2.0 * known_accuracy * unknown_recall / total


@dataclass(frozen=True)
class RescueMetrics:
    temporal_accuracy: float
    spectral_accuracy: float
    best_single_accuracy: float
    oracle_accuracy: float
    oracle_headroom: float
    temporal_rescues_spectral: float
    spectral_rescues_temporal: float
    bidirectional_rescue: bool


@dataclass(frozen=True)
class OpenSetRescueMetrics:
    temporal_known_accuracy: float
    spectral_known_accuracy: float
    temporal_unknown_recall: float
    spectral_unknown_recall: float
    temporal_h: float
    spectral_h: float
    best_single_h: float
    oracle_h: float
    oracle_headroom: float
    temporal_rescues_spectral: float
    spectral_rescues_temporal: float
    bidirectional_rescue: bool


def rescue_metrics(labels, temporal_prediction,
                   spectral_prediction) -> RescueMetrics:
    labels = np.asarray(labels).reshape(-1)
    temporal = np.asarray(temporal_prediction).reshape(-1)
    spectral = np.asarray(spectral_prediction).reshape(-1)
    if not len(labels) or labels.shape != temporal.shape or labels.shape != spectral.shape:
        raise ValueError("labels and predictions must be matching non-empty vectors")
    temporal_ok = temporal == labels
    spectral_ok = spectral == labels
    temporal_accuracy = float(temporal_ok.mean())
    spectral_accuracy = float(spectral_ok.mean())
    oracle = temporal_ok | spectral_ok
    temporal_rescue = float((temporal_ok & ~spectral_ok).mean())
    spectral_rescue = float((spectral_ok & ~temporal_ok).mean())
    best = max(temporal_accuracy, spectral_accuracy)
    return RescueMetrics(
        temporal_accuracy=temporal_accuracy,
        spectral_accuracy=spectral_accuracy,
        best_single_accuracy=best,
        oracle_accuracy=float(oracle.mean()),
        oracle_headroom=float(oracle.mean()) - best,
        temporal_rescues_spectral=temporal_rescue,
        spectral_rescues_temporal=spectral_rescue,
        bidirectional_rescue=temporal_rescue > 0 and spectral_rescue > 0)


def rescue_labels(labels, temporal_prediction, spectral_prediction) -> np.ndarray:
    """0 none/both, 1 temporal uniquely wins, 2 spectral uniquely wins."""

    labels = np.asarray(labels).reshape(-1)
    temporal_ok = np.asarray(temporal_prediction).reshape(-1) == labels
    spectral_ok = np.asarray(spectral_prediction).reshape(-1) == labels
    result = np.zeros(len(labels), dtype=np.int64)
    result[temporal_ok & ~spectral_ok] = 1
    result[spectral_ok & ~temporal_ok] = 2
    return result


def open_set_rescue_metrics(labels, temporal_prediction,
                            spectral_prediction) -> OpenSetRescueMetrics:
    """Measure rescue and oracle H from final predictions (``-1`` = reject)."""

    labels = np.asarray(labels, dtype=np.int64).reshape(-1)
    temporal = np.asarray(temporal_prediction, dtype=np.int64).reshape(-1)
    spectral = np.asarray(spectral_prediction, dtype=np.int64).reshape(-1)
    if not len(labels) or labels.shape != temporal.shape or labels.shape != spectral.shape:
        raise ValueError("labels and predictions must be matching non-empty vectors")
    known = labels >= 0
    unknown = ~known
    if not known.any() or not unknown.any():
        raise ValueError("open-set rescue metrics require Known and proxy Unknown samples")
    temporal_ok = temporal == labels
    spectral_ok = spectral == labels
    temporal_known = float(temporal_ok[known].mean())
    spectral_known = float(spectral_ok[known].mean())
    temporal_unknown = float(temporal_ok[unknown].mean())
    spectral_unknown = float(spectral_ok[unknown].mean())
    temporal_h = _safe_h(temporal_known, temporal_unknown)
    spectral_h = _safe_h(spectral_known, spectral_unknown)
    oracle_ok = temporal_ok | spectral_ok
    oracle_h = _safe_h(
        float(oracle_ok[known].mean()), float(oracle_ok[unknown].mean()))
    temporal_rescue = float((temporal_ok & ~spectral_ok).mean())
    spectral_rescue = float((spectral_ok & ~temporal_ok).mean())
    best = max(temporal_h, spectral_h)
    return OpenSetRescueMetrics(
        temporal_known_accuracy=temporal_known,
        spectral_known_accuracy=spectral_known,
        temporal_unknown_recall=temporal_unknown,
        spectral_unknown_recall=spectral_unknown,
        temporal_h=temporal_h, spectral_h=spectral_h,
        best_single_h=best, oracle_h=oracle_h,
        oracle_headroom=oracle_h - best,
        temporal_rescues_spectral=temporal_rescue,
        spectral_rescues_temporal=spectral_rescue,
        bidirectional_rescue=temporal_rescue > 0 and spectral_rescue > 0)


def open_set_h_metrics(labels, prediction, reject) -> dict[str, float]:
    labels = np.asarray(labels).reshape(-1)
    prediction = np.asarray(prediction).reshape(-1)
    reject = np.asarray(reject, dtype=bool).reshape(-1)
    known = labels >= 0
    unknown = ~known
    known_accuracy = float(((prediction[known] == labels[known]) & ~reject[known]).mean())
    unknown_recall = float(reject[unknown].mean()) if unknown.any() else 0.0
    return {
        "known_accuracy": known_accuracy,
        "unknown_recall": unknown_recall,
        "h_score": _safe_h(known_accuracy, unknown_recall),
    }
