"""Local specialization and candidate-conditioned verifier objectives."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch
from torch.nn import functional as F

from .contracts import LocalDecision


@dataclass(frozen=True)
class VerifierObjective:
    loss: torch.Tensor
    classification_loss: torch.Tensor
    positive_loss: torch.Tensor
    hard_negative_loss: torch.Tensor
    pair_margin_loss: torch.Tensor
    hard_negative: torch.Tensor


def candidate_conditioned_verifier_objective(
    agent: Any,
    private_state: object,
    decision: LocalDecision,
    labels: torch.Tensor,
    *,
    verification_weight: float = 1.0,
    pair_margin: float = 0.5,
) -> VerifierObjective:
    """Train true-candidate support against the closest current competitor."""

    labels = labels.long().to(decision.class_logits.device)
    if labels.shape != (len(decision.class_logits),) or bool((labels < 0).any()):
        raise ValueError("candidate verifier training requires Known labels [batch]")
    if verification_weight < 0 or pair_margin < 0:
        raise ValueError("verification_weight and pair_margin must be non-negative")
    masked = decision.class_logits.detach().clone()
    masked.scatter_(1, labels[:, None], float("-inf"))
    hard_negative = masked.argmax(1)
    positive_score = agent.verification_scores(private_state, labels)
    negative_score = agent.verification_scores(private_state, hard_negative)
    classification = F.cross_entropy(decision.class_logits, labels)
    positive = F.binary_cross_entropy_with_logits(
        positive_score, torch.ones_like(positive_score))
    negative = F.binary_cross_entropy_with_logits(
        negative_score, torch.zeros_like(negative_score))
    pair = F.relu(float(pair_margin) - positive_score + negative_score).mean()
    loss = classification + float(verification_weight) * (positive + negative + pair)
    return VerifierObjective(
        loss=loss, classification_loss=classification,
        positive_loss=positive, hard_negative_loss=negative,
        pair_margin_loss=pair, hard_negative=hard_negative)


def local_specialization_objective(system, temporal_observation,
                                   spectral_observation,
                                   labels: torch.Tensor, *,
                                   verification_weight: float = 1.0,
                                   pair_margin: float = 0.5):
    """Compute independent unit-scale A/B objectives without cross-view state."""

    temporal_decision, temporal_private = system.temporal.forward_private(
        temporal_observation)
    spectral_decision, spectral_private = system.spectral.forward_private(
        spectral_observation)
    temporal = candidate_conditioned_verifier_objective(
        system.temporal, temporal_private, temporal_decision, labels,
        verification_weight=verification_weight, pair_margin=pair_margin)
    spectral = candidate_conditioned_verifier_objective(
        system.spectral, spectral_private, spectral_decision, labels,
        verification_weight=verification_weight, pair_margin=pair_margin)
    return temporal.loss + spectral.loss, {
        "temporal": temporal, "spectral": spectral,
        "decisions": {"temporal": temporal_decision,
                      "spectral": spectral_decision},
    }

