import sys
from pathlib import Path

import pytest
import torch


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from maros_stage8.observations import (SpectralObservation,  # noqa: E402
                                       TemporalObservation,
                                       build_spectral_observation)


def test_observation_shapes_are_strict_and_immutable():
    iq = torch.randn(3, 2, 64)
    temporal = TemporalObservation(iq)
    spectral = build_spectral_observation(iq)
    assert temporal.iq.shape == (3, 2, 64)
    assert spectral.features.shape == (3, 6, 64)
    assert spectral.quality.shape == (3, 6)
    with pytest.raises(Exception):
        temporal.iq = torch.zeros_like(iq)


@pytest.mark.parametrize("bad", [
    torch.randn(3, 64),
    torch.randn(3, 3, 64),
    torch.ones(3, 2, 8),
])
def test_temporal_contract_rejects_invalid_iq(bad):
    with pytest.raises((TypeError, ValueError)):
        TemporalObservation(bad)


def test_spectral_contract_rejects_raw_shaped_payload():
    with pytest.raises(ValueError, match="spectral features"):
        SpectralObservation(torch.randn(3, 2, 64), torch.randn(3, 6))

