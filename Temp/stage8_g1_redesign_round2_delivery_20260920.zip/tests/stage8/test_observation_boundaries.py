import sys
from pathlib import Path

import pytest
import torch


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from maros_stage8.observations import (CoarseSpectralObservation,  # noqa: E402
                                       SpectralObservation,
                                       TemporalObservation,
                                       TemporalPatchObservation,
                                       build_coarse_spectral_observation,
                                       build_spectral_observation,
                                       build_temporal_patch_observation)
from maros_stage8.system import Stage8System  # noqa: E402


def test_observation_shapes_are_strict_and_immutable():
    iq = torch.randn(3, 2, 64)
    temporal = TemporalObservation(iq)
    spectral = build_spectral_observation(iq)
    assert temporal.iq.shape == (3, 2, 64)
    assert spectral.features.shape == (3, 6, 64)
    assert spectral.quality.shape == (3, 6)
    with pytest.raises(Exception):
        temporal.iq = torch.zeros_like(iq)


@pytest.mark.parametrize("bad", [
    torch.randn(3, 64),
    torch.randn(3, 3, 64),
    torch.ones(3, 2, 8),
])
def test_temporal_contract_rejects_invalid_iq(bad):
    with pytest.raises((TypeError, ValueError)):
        TemporalObservation(bad)


def test_spectral_contract_rejects_raw_shaped_payload():
    with pytest.raises(ValueError, match="spectral features"):
        SpectralObservation(torch.randn(3, 2, 64), torch.randn(3, 6))


def test_information_isolated_v2_observations_are_lossy_and_typed():
    iq = torch.randn(3, 2, 256)
    temporal = build_temporal_patch_observation(iq)
    spectral = build_coarse_spectral_observation(iq)
    assert isinstance(temporal, TemporalPatchObservation)
    assert isinstance(spectral, CoarseSpectralObservation)
    assert temporal.features.shape == (3, 8, 32)
    assert temporal.quality.shape == (3, 3)
    assert spectral.features.shape == (3, 8, 64)
    assert spectral.quality.shape == (3, 8)
    assert not hasattr(temporal, "iq")
    assert not hasattr(spectral, "iq")
    assert set(temporal.__dataclass_fields__) == {"features", "quality"}
    assert set(spectral.__dataclass_fields__) == {"features", "quality"}


def test_isolated_v2_system_rejects_legacy_observations():
    iq = torch.randn(3, 2, 256)
    system = Stage8System(
        3, state_dim=8, hidden_channels=4,
        observation_profile="isolated_v2")
    context = system.observe(iq)
    assert context["temporal"].class_logits.shape == (3, 3)
    assert context["spectral"].class_logits.shape == (3, 3)
    with pytest.raises(TypeError, match="TemporalPatchObservation"):
        system.temporal(TemporalObservation(iq))
    with pytest.raises(TypeError, match="configured SpectralObservation"):
        system.spectral(build_spectral_observation(iq))
